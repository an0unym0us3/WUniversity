from Templates import Template

University1 = Template(title = 'Aizu')
University1.run()